# Ceres GTK theme
Forked from [Fluent](https://github.com/vinceliuice/Fluent-gtk-theme)